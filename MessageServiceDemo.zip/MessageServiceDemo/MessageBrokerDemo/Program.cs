﻿// See https://aka.ms/new-console-template for more information
using MessageBrokerDemo;

Console.WriteLine("Hello, World!");
Application application = new Application();
application.Run(); 